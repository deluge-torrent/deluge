from deluge.ui.gtkui.gtkui import start
assert start  # silence pyflakes
