#!/bin/sh

ext-doc -p deluge-docs.xml -o build -t template/template.xml
