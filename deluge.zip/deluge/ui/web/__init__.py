from deluge.ui.web.web import start
assert start  # silence pyflakes
