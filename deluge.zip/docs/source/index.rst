.. deluge documentation master file, created by sphinx-quickstart on Tue Nov  4 18:24:06 2008.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to Deluge's Documentation!
==================================

Contents:

.. toctree::
   :maxdepth: 2

   Core <core/index.rst>
   Interfaces <interfaces/index.rst>

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

Modules
=======

.. toctree::
   :maxdepth: 2
   :glob:

   modules/*
