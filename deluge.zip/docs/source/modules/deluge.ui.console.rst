deluge.ui.console package
=========================

Subpackages
-----------

.. toctree::

    deluge.ui.console.commands
    deluge.ui.console.modes

Submodules
----------

deluge.ui.console.colors module
-------------------------------

.. automodule:: deluge.ui.console.colors
    :members:
    :undoc-members:
    :show-inheritance:

deluge.ui.console.commander module
----------------------------------

.. automodule:: deluge.ui.console.commander
    :members:
    :undoc-members:
    :show-inheritance:

deluge.ui.console.eventlog module
---------------------------------

.. automodule:: deluge.ui.console.eventlog
    :members:
    :undoc-members:
    :show-inheritance:

deluge.ui.console.main module
-----------------------------

.. automodule:: deluge.ui.console.main
    :members:
    :undoc-members:
    :show-inheritance:

deluge.ui.console.statusbars module
-----------------------------------

.. automodule:: deluge.ui.console.statusbars
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: deluge.ui.console
    :members:
    :undoc-members:
    :show-inheritance:
