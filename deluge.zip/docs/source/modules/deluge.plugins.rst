deluge.plugins package
======================

Submodules
----------

deluge.plugins.init module
--------------------------

.. automodule:: deluge.plugins.init
    :members:
    :undoc-members:
    :show-inheritance:

deluge.plugins.pluginbase module
--------------------------------

.. automodule:: deluge.plugins.pluginbase
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: deluge.plugins
    :members:
    :undoc-members:
    :show-inheritance:
