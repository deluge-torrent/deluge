deluge.ui.console.modes package
===============================

Submodules
----------

deluge.ui.console.modes.add_util module
---------------------------------------

.. automodule:: deluge.ui.console.modes.add_util
    :members:
    :undoc-members:
    :show-inheritance:

deluge.ui.console.modes.addtorrents module
------------------------------------------

.. automodule:: deluge.ui.console.modes.addtorrents
    :members:
    :undoc-members:
    :show-inheritance:

deluge.ui.console.modes.alltorrents module
------------------------------------------

.. automodule:: deluge.ui.console.modes.alltorrents
    :members:
    :undoc-members:
    :show-inheritance:

deluge.ui.console.modes.basemode module
---------------------------------------

.. automodule:: deluge.ui.console.modes.basemode
    :members:
    :undoc-members:
    :show-inheritance:

deluge.ui.console.modes.column module
-------------------------------------

.. automodule:: deluge.ui.console.modes.column
    :members:
    :undoc-members:
    :show-inheritance:

deluge.ui.console.modes.connectionmanager module
------------------------------------------------

.. automodule:: deluge.ui.console.modes.connectionmanager
    :members:
    :undoc-members:
    :show-inheritance:

deluge.ui.console.modes.eventview module
----------------------------------------

.. automodule:: deluge.ui.console.modes.eventview
    :members:
    :undoc-members:
    :show-inheritance:

deluge.ui.console.modes.format_utils module
-------------------------------------------

.. automodule:: deluge.ui.console.modes.format_utils
    :members:
    :undoc-members:
    :show-inheritance:

deluge.ui.console.modes.input_popup module
------------------------------------------

.. automodule:: deluge.ui.console.modes.input_popup
    :members:
    :undoc-members:
    :show-inheritance:

deluge.ui.console.modes.legacy module
-------------------------------------

.. automodule:: deluge.ui.console.modes.legacy
    :members:
    :undoc-members:
    :show-inheritance:

deluge.ui.console.modes.popup module
------------------------------------

.. automodule:: deluge.ui.console.modes.popup
    :members:
    :undoc-members:
    :show-inheritance:

deluge.ui.console.modes.preference_panes module
-----------------------------------------------

.. automodule:: deluge.ui.console.modes.preference_panes
    :members:
    :undoc-members:
    :show-inheritance:

deluge.ui.console.modes.preferences module
------------------------------------------

.. automodule:: deluge.ui.console.modes.preferences
    :members:
    :undoc-members:
    :show-inheritance:

deluge.ui.console.modes.torrent_actions module
----------------------------------------------

.. automodule:: deluge.ui.console.modes.torrent_actions
    :members:
    :undoc-members:
    :show-inheritance:

deluge.ui.console.modes.torrentdetail module
--------------------------------------------

.. automodule:: deluge.ui.console.modes.torrentdetail
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: deluge.ui.console.modes
    :members:
    :undoc-members:
    :show-inheritance:
