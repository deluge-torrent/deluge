deluge.ui.gtkui package
=======================

Submodules
----------

deluge.ui.gtkui.aboutdialog module
----------------------------------

.. automodule:: deluge.ui.gtkui.aboutdialog
    :members:
    :undoc-members:
    :show-inheritance:

deluge.ui.gtkui.addtorrentdialog module
---------------------------------------

.. automodule:: deluge.ui.gtkui.addtorrentdialog
    :members:
    :undoc-members:
    :show-inheritance:

deluge.ui.gtkui.common module
-----------------------------

.. automodule:: deluge.ui.gtkui.common
    :members:
    :undoc-members:
    :show-inheritance:

deluge.ui.gtkui.connectionmanager module
----------------------------------------

.. automodule:: deluge.ui.gtkui.connectionmanager
    :members:
    :undoc-members:
    :show-inheritance:

deluge.ui.gtkui.createtorrentdialog module
------------------------------------------

.. automodule:: deluge.ui.gtkui.createtorrentdialog
    :members:
    :undoc-members:
    :show-inheritance:

deluge.ui.gtkui.details_tab module
----------------------------------

.. automodule:: deluge.ui.gtkui.details_tab
    :members:
    :undoc-members:
    :show-inheritance:

deluge.ui.gtkui.dialogs module
------------------------------

.. automodule:: deluge.ui.gtkui.dialogs
    :members:
    :undoc-members:
    :show-inheritance:

deluge.ui.gtkui.edittrackersdialog module
-----------------------------------------

.. automodule:: deluge.ui.gtkui.edittrackersdialog
    :members:
    :undoc-members:
    :show-inheritance:

deluge.ui.gtkui.files_tab module
--------------------------------

.. automodule:: deluge.ui.gtkui.files_tab
    :members:
    :undoc-members:
    :show-inheritance:

deluge.ui.gtkui.filtertreeview module
-------------------------------------

.. automodule:: deluge.ui.gtkui.filtertreeview
    :members:
    :undoc-members:
    :show-inheritance:

deluge.ui.gtkui.gtkui module
----------------------------

.. automodule:: deluge.ui.gtkui.gtkui
    :members:
    :undoc-members:
    :show-inheritance:

deluge.ui.gtkui.ipcinterface module
-----------------------------------

.. automodule:: deluge.ui.gtkui.ipcinterface
    :members:
    :undoc-members:
    :show-inheritance:

deluge.ui.gtkui.listview module
-------------------------------

.. automodule:: deluge.ui.gtkui.listview
    :members:
    :undoc-members:
    :show-inheritance:

deluge.ui.gtkui.mainwindow module
---------------------------------

.. automodule:: deluge.ui.gtkui.mainwindow
    :members:
    :undoc-members:
    :show-inheritance:

deluge.ui.gtkui.menubar module
------------------------------

.. automodule:: deluge.ui.gtkui.menubar
    :members:
    :undoc-members:
    :show-inheritance:

deluge.ui.gtkui.menubar_osx module
----------------------------------

.. automodule:: deluge.ui.gtkui.menubar_osx
    :members:
    :undoc-members:
    :show-inheritance:

deluge.ui.gtkui.new_release_dialog module
-----------------------------------------

.. automodule:: deluge.ui.gtkui.new_release_dialog
    :members:
    :undoc-members:
    :show-inheritance:

deluge.ui.gtkui.notification module
-----------------------------------

.. automodule:: deluge.ui.gtkui.notification
    :members:
    :undoc-members:
    :show-inheritance:

deluge.ui.gtkui.options_tab module
----------------------------------

.. automodule:: deluge.ui.gtkui.options_tab
    :members:
    :undoc-members:
    :show-inheritance:

deluge.ui.gtkui.path_chooser module
-----------------------------------

.. automodule:: deluge.ui.gtkui.path_chooser
    :members:
    :undoc-members:
    :show-inheritance:

deluge.ui.gtkui.path_combo_chooser module
-----------------------------------------

.. automodule:: deluge.ui.gtkui.path_combo_chooser
    :members:
    :undoc-members:
    :show-inheritance:

deluge.ui.gtkui.peers_tab module
--------------------------------

.. automodule:: deluge.ui.gtkui.peers_tab
    :members:
    :undoc-members:
    :show-inheritance:

deluge.ui.gtkui.piecesbar module
--------------------------------

.. automodule:: deluge.ui.gtkui.piecesbar
    :members:
    :undoc-members:
    :show-inheritance:

deluge.ui.gtkui.pluginmanager module
------------------------------------

.. automodule:: deluge.ui.gtkui.pluginmanager
    :members:
    :undoc-members:
    :show-inheritance:

deluge.ui.gtkui.preferences module
----------------------------------

.. automodule:: deluge.ui.gtkui.preferences
    :members:
    :undoc-members:
    :show-inheritance:

deluge.ui.gtkui.queuedtorrents module
-------------------------------------

.. automodule:: deluge.ui.gtkui.queuedtorrents
    :members:
    :undoc-members:
    :show-inheritance:

deluge.ui.gtkui.removetorrentdialog module
------------------------------------------

.. automodule:: deluge.ui.gtkui.removetorrentdialog
    :members:
    :undoc-members:
    :show-inheritance:

deluge.ui.gtkui.sidebar module
------------------------------

.. automodule:: deluge.ui.gtkui.sidebar
    :members:
    :undoc-members:
    :show-inheritance:

deluge.ui.gtkui.status_tab module
---------------------------------

.. automodule:: deluge.ui.gtkui.status_tab
    :members:
    :undoc-members:
    :show-inheritance:

deluge.ui.gtkui.statusbar module
--------------------------------

.. automodule:: deluge.ui.gtkui.statusbar
    :members:
    :undoc-members:
    :show-inheritance:

deluge.ui.gtkui.systemtray module
---------------------------------

.. automodule:: deluge.ui.gtkui.systemtray
    :members:
    :undoc-members:
    :show-inheritance:

deluge.ui.gtkui.toolbar module
------------------------------

.. automodule:: deluge.ui.gtkui.toolbar
    :members:
    :undoc-members:
    :show-inheritance:

deluge.ui.gtkui.torrentdetails module
-------------------------------------

.. automodule:: deluge.ui.gtkui.torrentdetails
    :members:
    :undoc-members:
    :show-inheritance:

deluge.ui.gtkui.torrentview module
----------------------------------

.. automodule:: deluge.ui.gtkui.torrentview
    :members:
    :undoc-members:
    :show-inheritance:

deluge.ui.gtkui.torrentview_data_funcs module
---------------------------------------------

.. automodule:: deluge.ui.gtkui.torrentview_data_funcs
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: deluge.ui.gtkui
    :members:
    :undoc-members:
    :show-inheritance:
