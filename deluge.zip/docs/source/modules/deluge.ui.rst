deluge.ui package
=================

Subpackages
-----------

.. toctree::

    deluge.ui.console
    deluge.ui.gtkui
    deluge.ui.web

Submodules
----------

deluge.ui.Win32IconImagePlugin module
-------------------------------------

.. automodule:: deluge.ui.Win32IconImagePlugin
    :members:
    :undoc-members:
    :show-inheritance:

deluge.ui.client module
-----------------------

.. automodule:: deluge.ui.client
    :members:
    :undoc-members:
    :show-inheritance:

deluge.ui.common module
-----------------------

.. automodule:: deluge.ui.common
    :members:
    :undoc-members:
    :show-inheritance:

deluge.ui.coreconfig module
---------------------------

.. automodule:: deluge.ui.coreconfig
    :members:
    :undoc-members:
    :show-inheritance:

deluge.ui.countries module
--------------------------

.. automodule:: deluge.ui.countries
    :members:
    :undoc-members:
    :show-inheritance:

deluge.ui.languages module
--------------------------

.. automodule:: deluge.ui.languages
    :members:
    :undoc-members:
    :show-inheritance:

deluge.ui.sessionproxy module
-----------------------------

.. automodule:: deluge.ui.sessionproxy
    :members:
    :undoc-members:
    :show-inheritance:

deluge.ui.tracker_icons module
------------------------------

.. automodule:: deluge.ui.tracker_icons
    :members:
    :undoc-members:
    :show-inheritance:

deluge.ui.ui module
-------------------

.. automodule:: deluge.ui.ui
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: deluge.ui
    :members:
    :undoc-members:
    :show-inheritance:
