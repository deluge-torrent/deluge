deluge.ui.web package
=====================

Submodules
----------

deluge.ui.web.auth module
-------------------------

.. automodule:: deluge.ui.web.auth
    :members:
    :undoc-members:
    :show-inheritance:

deluge.ui.web.common module
---------------------------

.. automodule:: deluge.ui.web.common
    :members:
    :undoc-members:
    :show-inheritance:

deluge.ui.web.json_api module
-----------------------------

.. automodule:: deluge.ui.web.json_api
    :members:
    :undoc-members:
    :show-inheritance:

deluge.ui.web.pluginmanager module
----------------------------------

.. automodule:: deluge.ui.web.pluginmanager
    :members:
    :undoc-members:
    :show-inheritance:

deluge.ui.web.server module
---------------------------

.. automodule:: deluge.ui.web.server
    :members:
    :undoc-members:
    :show-inheritance:

deluge.ui.web.web module
------------------------

.. automodule:: deluge.ui.web.web
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: deluge.ui.web
    :members:
    :undoc-members:
    :show-inheritance:
