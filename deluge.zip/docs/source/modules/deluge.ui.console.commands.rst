deluge.ui.console.commands package
==================================

Submodules
----------

deluge.ui.console.commands.add module
-------------------------------------

.. automodule:: deluge.ui.console.commands.add
    :members:
    :undoc-members:
    :show-inheritance:

deluge.ui.console.commands.cache module
---------------------------------------

.. automodule:: deluge.ui.console.commands.cache
    :members:
    :undoc-members:
    :show-inheritance:

deluge.ui.console.commands.config module
----------------------------------------

.. automodule:: deluge.ui.console.commands.config
    :members:
    :undoc-members:
    :show-inheritance:

deluge.ui.console.commands.connect module
-----------------------------------------

.. automodule:: deluge.ui.console.commands.connect
    :members:
    :undoc-members:
    :show-inheritance:

deluge.ui.console.commands.debug module
---------------------------------------

.. automodule:: deluge.ui.console.commands.debug
    :members:
    :undoc-members:
    :show-inheritance:

deluge.ui.console.commands.gui module
-------------------------------------

.. automodule:: deluge.ui.console.commands.gui
    :members:
    :undoc-members:
    :show-inheritance:

deluge.ui.console.commands.halt module
--------------------------------------

.. automodule:: deluge.ui.console.commands.halt
    :members:
    :undoc-members:
    :show-inheritance:

deluge.ui.console.commands.help module
--------------------------------------

.. automodule:: deluge.ui.console.commands.help
    :members:
    :undoc-members:
    :show-inheritance:

deluge.ui.console.commands.info module
--------------------------------------

.. automodule:: deluge.ui.console.commands.info
    :members:
    :undoc-members:
    :show-inheritance:

deluge.ui.console.commands.manage module
----------------------------------------

.. automodule:: deluge.ui.console.commands.manage
    :members:
    :undoc-members:
    :show-inheritance:

deluge.ui.console.commands.move module
--------------------------------------

.. automodule:: deluge.ui.console.commands.move
    :members:
    :undoc-members:
    :show-inheritance:

deluge.ui.console.commands.pause module
---------------------------------------

.. automodule:: deluge.ui.console.commands.pause
    :members:
    :undoc-members:
    :show-inheritance:

deluge.ui.console.commands.plugin module
----------------------------------------

.. automodule:: deluge.ui.console.commands.plugin
    :members:
    :undoc-members:
    :show-inheritance:

deluge.ui.console.commands.quit module
--------------------------------------

.. automodule:: deluge.ui.console.commands.quit
    :members:
    :undoc-members:
    :show-inheritance:

deluge.ui.console.commands.recheck module
-----------------------------------------

.. automodule:: deluge.ui.console.commands.recheck
    :members:
    :undoc-members:
    :show-inheritance:

deluge.ui.console.commands.resume module
----------------------------------------

.. automodule:: deluge.ui.console.commands.resume
    :members:
    :undoc-members:
    :show-inheritance:

deluge.ui.console.commands.rm module
------------------------------------

.. automodule:: deluge.ui.console.commands.rm
    :members:
    :undoc-members:
    :show-inheritance:

deluge.ui.console.commands.status module
----------------------------------------

.. automodule:: deluge.ui.console.commands.status
    :members:
    :undoc-members:
    :show-inheritance:

deluge.ui.console.commands.update-tracker module
------------------------------------------------

.. automodule:: deluge.ui.console.commands.update_tracker
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: deluge.ui.console.commands
    :members:
    :undoc-members:
    :show-inheritance:
