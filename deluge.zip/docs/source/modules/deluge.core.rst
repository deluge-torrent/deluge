deluge.core package
===================

Submodules
----------

deluge.core.alertmanager module
-------------------------------

.. automodule:: deluge.core.alertmanager
    :members:
    :undoc-members:
    :show-inheritance:

deluge.core.authmanager module
------------------------------

.. automodule:: deluge.core.authmanager
    :members:
    :undoc-members:
    :show-inheritance:

deluge.core.core module
-----------------------

.. automodule:: deluge.core.core
    :members:
    :undoc-members:
    :show-inheritance:

deluge.core.daemon module
-------------------------

.. automodule:: deluge.core.daemon
    :members:
    :undoc-members:
    :show-inheritance:

deluge.core.eventmanager module
-------------------------------

.. automodule:: deluge.core.eventmanager
    :members:
    :undoc-members:
    :show-inheritance:

deluge.core.filtermanager module
--------------------------------

.. automodule:: deluge.core.filtermanager
    :members:
    :undoc-members:
    :show-inheritance:

deluge.core.pluginmanager module
--------------------------------

.. automodule:: deluge.core.pluginmanager
    :members:
    :undoc-members:
    :show-inheritance:

deluge.core.preferencesmanager module
-------------------------------------

.. automodule:: deluge.core.preferencesmanager
    :members:
    :undoc-members:
    :show-inheritance:

deluge.core.rpcserver module
----------------------------

.. automodule:: deluge.core.rpcserver
    :members:
    :undoc-members:
    :show-inheritance:

deluge.core.torrent module
--------------------------

.. automodule:: deluge.core.torrent
    :members:
    :undoc-members:
    :show-inheritance:

deluge.core.torrentmanager module
---------------------------------

.. automodule:: deluge.core.torrentmanager
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: deluge.core
    :members:
    :undoc-members:
    :show-inheritance:
