Deluge Console UI
=================