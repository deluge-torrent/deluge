Deluge GTK UI
=============