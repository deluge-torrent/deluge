Deluge's Interfaces
===================

Interfaces.

.. toctree::

    Gtk Interface <gtk>
    Web Interface <web>
    Console Interface <console>